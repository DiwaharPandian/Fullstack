package com.fullstack.service;

import com.fullstack.model.User;



public interface LoginService {
	public int validateUser(User user);

}

package com.fullstack.service.impl;

import java.util.List;
import org.springframework.stereotype.Service;
import com.fullstack.model.FileEntity;
import com.fullstack.service.FileService;

@Service
public class FileServiceImpl implements FileService {

	public void saveFileUpload(FileEntity fileEntity) {

	}

	public List<FileEntity> viewAllFiles() {
		return null;
	}

	public List<FileEntity> findByName(String fileName) {
		return null;
	}

}

package com.fullstack.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fullstack.dao.impl.RegisterDaoImpl;
import com.fullstack.model.User;
import com.fullstack.service.RegisterService;

@Service("RegisterService")
public class RegisterServiceImpl implements RegisterService {

	@Autowired
	private RegisterDaoImpl registerDaoImpl;

	@Transactional
	public void saveRegister(User customer) {
		registerDaoImpl.saveRegister(customer);
	}

	public List<User> getAllUsers() {
		return registerDaoImpl.getAllUsers();
	}

}

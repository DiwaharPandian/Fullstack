package com.fullstack.service;

import java.util.List;

import com.fullstack.model.User;



public interface RegisterService {

	public void saveRegister(User user);
	public List<User> getAllUsers();
}

package com.fullstack.dao;

import com.fullstack.model.User;

public interface LoginDao {
	public int validateUser(User user);
}

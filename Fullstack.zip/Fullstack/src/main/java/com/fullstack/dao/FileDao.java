package com.fullstack.dao;

import java.util.List;

import com.fullstack.model.FileEntity;

public interface FileDao {
	public void saveFileUpload(FileEntity fileEntity);

	public List<FileEntity> viewAllFiles();

	public List<FileEntity> findByName(String fileName);
}

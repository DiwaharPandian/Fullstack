package com.fullstack.dao;

import java.util.List;

import com.fullstack.model.User;

public interface RegisterDao {
	public void saveRegister(User user);

	public List<User> getAllUsers();
}

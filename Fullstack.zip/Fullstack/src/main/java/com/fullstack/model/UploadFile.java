package com.fullstack.model;

public class UploadFile {
	
}

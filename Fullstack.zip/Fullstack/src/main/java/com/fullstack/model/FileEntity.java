package com.fullstack.model;


public class FileEntity {

  
}

